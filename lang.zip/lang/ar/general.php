<?php

return [

    "app_name" => "VPM",

    "online" => "Online",

    "dashboard" => "Dashboard",

    "current_status" => "الحالة الحالية",

    "active" => "نشط",

    "inactive" => "غير نشط",

    "total" => "الاجمالي",

    "wallet" => "المحفظه",

    "good" => "جيد",

    "bad" => "سئ",

    "sar" => "ريال",

    "date" => "تاريخ",

    "to" => "الي",

    "from" => "من",

    "mr" => "السيد \ ة",

    "email" => "البريد الالكتروني",

    "period" => "فترة",

    "all" => "الكل",

    "ASC" => "تصاعدي",

    "DESC" => "تنازلي",

];
