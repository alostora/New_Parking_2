<?php

return [

    'page_title' => 'Company Rating',

    'filter' => 'Filter',

    'query_string' => 'Query String',

    'select' => 'Select',

    'client' => 'Client',

    'company' => 'Company',

    'employee' => 'Employee',

    'available_rating' => 'Rating Type',

    'rating_value' => 'Rating Value',

    'created_at' => 'Created At',

    "search" => "Search",

    "empty" => "Empty",

    "current_status" => "Current Status",

    "active" => "Active",

    "inactive" => "Inactive",

    'payer_name' => 'Payer Name',

    'payer_email' => 'Payer Email',

    'payer_phone' => 'Payer Phone',

    'total_bad_count' => 'Bad Count',

    'total_good_count' => 'Good Count',
    "good" => "Good",
    "bad" => "Bad",
];
