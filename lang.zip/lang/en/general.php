<?php

return [

    "app_name" => "VPM",

    "online" => "Online",

    "dashboard" => "Dashboard",

    "current_status" => "Current Status",

    "active" => "Active",

    "inactive" => "Inactive",

    "total" => "Total",

    "wallet" => "Wallet",

    "good" => "Good",
    "bad" => "Bad",

    "sar" => "SAR",

    "date" => "Date",


    "to" => "To",

    "from" => "From",

    "mr" => "Mr/s",

    "email" => "Email",

    "period" => "Period",

    "all" => "الكل",

    "ASC" => "ASC",

    "DESC" => "DESC",

];
