<?php

return [

    'page_title' => 'Clients Notes',

    'filter' => 'Filter',

    'query_string' => 'Query String',

    'select' => 'Select',

    'client' => 'Client',

    'company' => 'Company',

    'employee' => 'Employee',

    'notes' => 'Notes',

    'payer_name' => 'Notes Owner',

    'payer_phone' => 'Notes Phone Owner',

    'created_at' => 'Created At',

    "search" => "Search",

    "empty" => "Empty",
    "current_status" => "Current Status",
    "active" => "Active",
    "inactive" => "Inactive",
];
