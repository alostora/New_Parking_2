<?php

return [

     "filter" => "Filter",

     "clients" => "Clients",

     "select" => "Select",

     "status" => "Status",

     "query_string" => "Query String",

     "search" => "Search",

     "date_from" => "Date From",

     "date_to" => "Date To",

     "employees" => "Employees",

     "companies" => "Companies",

     "user_account_type" => "User Account Type",

     "countries" => "Countries",

     "rating_value" => "Rating Value",

     "all" => "All",

     "active" => "Active",

     "inactive" => "Inactive",
     "good" => "Good",
     "bad" => "Bad",

];
