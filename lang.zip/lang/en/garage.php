<?php

return [

    'page_title' => 'Garages',
    'filter' => 'Filter',
    'query_string' => 'Query String',
    'select' => 'Select',

    'name' => 'Name',
    'name' => 'Name (AR)',
    'site_number' => 'Site Number',



    'phone' => 'Phone',
    'address' => 'Address',
    'user_account_type' => 'Account Type',
    'withdrawal_requests' => 'Withdrawal Requests',


    //operatoins
    "operations" => "Operations",
    "create" => "Create Garage",
    "update" => "Update Garage",
    "submit" => "Submit",
    "search" => "Search",
    "empty" => "Empty",
    "current_status" => "Current Status",
    "active" => "Active",
    "inactive" => "Inactive",
];
