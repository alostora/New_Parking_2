<?php

return [

    'create' => 'Please fill the form to get discount for one hour at any VPM garages',
    'please_save_qr_code' => 'Please save the qr code to get the discount while leave the garage',

    'name' => 'name',
    'email' => ' email',
    'phone' => 'phone',

    "submit" => "Submit",

];
